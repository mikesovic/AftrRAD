#! /usr/bin/perl
use warnings;
use strict;


print "Enter the name of the haplotypes file to use. Names of pairs of replicate samples should be stored in a file named Replicates.txt\n";
print "Each pair of replicates should be stored on a separate line, and separated by a tab.\n";
my $FileName = <STDIN>;
chomp($FileName);

open REPLICATES, "Replicates.txt" or die$!;

my %ReplicateNames = ();

while (<REPLICATES>)  {
	
	if ($_ =~ /[a-zA-Z]/)  {
		
		chomp($_);
		my @TempArray = split(/\t/,$_);
		$ReplicateNames{$TempArray[0]} = $TempArray[1];
	}
}









################################################################################################################################
#Create file with each individual in one line with haplotypes separated by a /.

open HAPLOTYPES, "../Output/Genotypes/$FileName" or die$!;
system "mkdir TempFiles_Dup";

open INFILE, ">TempFiles_Dup/SlashFile.txt" or die$!;

my $LineCounter = 0;
my @Array1;
my @Array2;

while(<HAPLOTYPES>)  {
	
	chomp($_);
	
	if ($_ =~ /Locus/)  {
		print INFILE "$_\n";
		next;
	}
	
	if ($LineCounter == 0) {
		
		@Array1 = split (/\t/, $_);
		$LineCounter=1;
		next;
	}	
	
	if ($LineCounter == 1)  {
		
		
		@Array2 = split (/\t/, $_);
		$LineCounter=0;
		
		print INFILE "$Array1[0]\t";
		
		my $ArrayLength = @Array1;
		
		
		foreach my $value (1..$ArrayLength-1)  {
			
			
			if ($Array1[$value] =~ /NA/) {
				print INFILE "NA\t";
			}	
			
			else {
				print INFILE "$Array1[$value]";
				print INFILE "/";
				print INFILE "$Array2[$value]\t";
			
			}
		}
		
		print INFILE "\n";
	}
}



close INFILE;
close HAPLOTYPES;










system "cp TempFiles_Dup/SlashFile.txt TempFiles_Dup/SlashFile2.txt";


open HAPLOTYPES, "TempFiles_Dup/SlashFile.txt" or die$!;
open INFILE, ">Duplicate_Report.txt" or die$!;
print INFILE "Comparison\tSites_Compared\tNumber_Matches\tProportion_Matches\tSample1_Homozygous_Mismatches\tSample2_Homozygous_Mismatches\tDoublyHomozygousLociCompared\tHeterozygousLociForDropout\n";


my $TotalNonNAComparisons = 0;
my $TotalMatches = 0;

while(<HAPLOTYPES>)  {
	
	chomp($_);
	
	if ($_ =~ /Locus/)  {
		#print INFILE "$_\n";
		next;
	}


	else {
		
		my @TempArray = split(/\t/,$_);
		my $CurrentName = $TempArray[0];
		
		if (exists($ReplicateNames{$CurrentName})) {
			
			print INFILE "$CurrentName/$ReplicateNames{$CurrentName}";
			my $CurrentIndividualNonNAComparisons = 0;
			my $CurrentIndividualMatches = 0;
			my $FirstSampleHomozygousLoci = 0;
			my $SecondSampleHomozygousLoci = 0;
			my $DoublyHomozygousComparisons = 0;
			
			my @FirstDup = split(/\t/,$_);
			my @SecondDup = ();
			
			my $DupName = $ReplicateNames{$CurrentName};	#Get the name of the replicate sample.
			
			open HAPLOTYPESB, "TempFiles_Dup/SlashFile2.txt" or die$!;
			
			while (<HAPLOTYPESB>)  {
				
				if ($_ =~ /Locus/)  {
					#print INFILE "$_\n";
					next;
				}
				
				else {
					my @TempArray = split(/\t/,$_);
					
					if ($TempArray[0] eq $DupName)  {	#Find the replicate sample in the copied Slash file.  Assign this line to @SecondDup for direct comparison to @FirstDup.
						
						@SecondDup = @TempArray;
						last;
					}
				}
			}
			
			
			
			my $NumLoci = @FirstDup-1;
			#print "Number of loci is $NumLoci\n";
			
			
			foreach my $element (1..$NumLoci)  {
				
				
				my @CurrentHaplotype1 = split(/\//, $FirstDup[$element]);
				
				my $CurrentHaplotype1a = $CurrentHaplotype1[0];
				my $CurrentHaplotype1b = $CurrentHaplotype1[1];
				
			
				my @CurrentHaplotype2 = split(/\//, $SecondDup[$element]);
				
				my $CurrentHaplotype2a = $CurrentHaplotype2[0];
				my $CurrentHaplotype2b = $CurrentHaplotype2[1];
				
				if (($CurrentHaplotype1a =~ /NA/) || ($CurrentHaplotype2a =~ /NA/))  {
					next;
				}	
				
				$CurrentIndividualNonNAComparisons++;
				$TotalNonNAComparisons++;
				
				my $FirstHaplotype = $CurrentHaplotype1a.$CurrentHaplotype1b;  #use this as reference haplotype
				
				my $SecondHaplotypeA = $CurrentHaplotype2a.$CurrentHaplotype2b;
				my $SecondHaplotypeB = $CurrentHaplotype2b.$CurrentHaplotype2a;
				
				if (($FirstHaplotype eq $SecondHaplotypeA) || ($FirstHaplotype eq $SecondHaplotypeB))  {
					$CurrentIndividualMatches++;
					$TotalMatches++;
					
					if ($CurrentHaplotype1a eq $CurrentHaplotype1b)  {
						$DoublyHomozygousComparisons++;
					}	
				}
				
				elsif ($CurrentHaplotype1a eq $CurrentHaplotype1b)  {
					$FirstSampleHomozygousLoci++;
				}
				
				elsif ($CurrentHaplotype2a eq $CurrentHaplotype2b)  {
					$SecondSampleHomozygousLoci++;
				}	
					
					
				
			}
			
			print INFILE "$CurrentIndividualNonNAComparisons\t$CurrentIndividualMatches\t$FirstSampleHomozygousLoci\t$SecondSampleHomozygousLoci\t";
				
			my $CurrentIndividualProportionCorrect = $CurrentIndividualMatches/$CurrentIndividualNonNAComparisons;
			my $HeterzygousLociForDropout = $CurrentIndividualNonNAComparisons-$DoublyHomozygousComparisons;
			
			print INFILE "$CurrentIndividualProportionCorrect\t$DoublyHomozygousComparisons\t$HeterzygousLociForDropout\n";	
				
				
		}
	}

}	


my $TotalProportionCorrect = $TotalMatches/$TotalNonNAComparisons;


print INFILE "\n\nTotals\t";

print INFILE "$TotalNonNAComparisons\t$TotalMatches\t$TotalProportionCorrect\n";




















	
			
		
		
	
	

	
