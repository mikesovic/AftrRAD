DataTableFromFile<-read.table("../TempFiles/GenotypesUpdateNoTab.txt", header=TRUE, sep = "\t")

DataMatrix<-as.matrix(DataTableFromFile)
DataFrame<-data.frame(DataMatrix, stringsAsFactors=FALSE)
NumRowsInMatrix<-nrow(DataMatrix)
NumColsInMatrix<-ncol(DataMatrix)

NamesCol<-DataMatrix[,1]

#Create empty matrix and put sample names as first column.
RaxmlMatrix<-matrix(c("",NamesCol), ncol=1, nrow=NumRowsInMatrix+1)

#For each locus (column), first get the length of the aligned allele, including dashes

LocusLength<-0
IndelSeq<-0

for (a in 2:(NumColsInMatrix))  {

	IndelSeq=0
	
	for (b in 1:NumRowsInMatrix)  {

		if (length(grep("-", as.character(DataFrame[b,a]))) != 0)  {	#Current locus contains an indel.
			
			IndelSeq<-1
			break
		}	
		
		else if (as.character(DataFrame[b,a]) == "N") {
			next
		}

		else {
			
			LocusLength<-nchar(DataFrame[b,a])
			break
			
		}

	}
	
	if (IndelSeq==0) {	#Not a locus that contains indels.  Need to check for any missing data and expand the N to the number of sites in the locus.
	
		for (b in 1:NumRowsInMatrix)  {
			if (as.character(DataFrame[b,a]) == "N") {
				StringToAdd<-rep("N",LocusLength)
				StringToAdd<-noquote(StringToAdd)
				StringToAdd<-paste(StringToAdd,collapse='')
				DataFrame[b,a] = StringToAdd
			}
		}
	}

	if (IndelSeq==0)  {
	
		CurrentLocus<-colnames(DataFrame[a])
		
		CurrentLocusColToPrint<-c(CurrentLocus, DataFrame[,a])
		
		RaxmlMatrix<-cbind (RaxmlMatrix, CurrentLocusColToPrint)
	}	
}	

write.table(RaxmlMatrix, file = "../TempFiles/RaxmlMatrixRaw.txt", sep = "\t",row.names=FALSE, col.names=FALSE)
