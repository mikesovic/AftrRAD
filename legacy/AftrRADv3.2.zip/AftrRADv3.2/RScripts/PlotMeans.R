MeansToPlot<-scan(file="TempFiles/MeansForRPlot.txt")
pdf("RunInfo/NonZeroReadCountMeansHistogram500.pdf")
bin.width<-1
MeansToPlot1to500<-MeansToPlot[MeansToPlot<500]
hist(MeansToPlot1to500, breaks=seq(0,500,by=bin.width))
pdf("RunInfo/NonZeroReadCountMeansHistogram250.pdf")
MeansToPlot1to250<-MeansToPlot[MeansToPlot<250]
hist(MeansToPlot1to250, breaks=seq(0,250,by=bin.width))
pdf("RunInfo/NonZeroReadCountMeansHistogram50.pdf")
MeansToPlot1to50<-MeansToPlot[MeansToPlot<50]
hist(MeansToPlot1to50, breaks=seq(0,50,by=bin.width))
dev.off()