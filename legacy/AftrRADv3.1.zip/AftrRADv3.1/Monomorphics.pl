#! /usr/bin/perl
use warnings;
use strict;


#Set min coverage parameter

# -MinReads  Minimum coverage required at a locus in an individual to apply a binomial test and call a genotype.

my %RunArguments = ();

$RunArguments{MinReads} = 10;

for my $argument (@ARGV)  {
	my @TempArgs = split(/-/,$argument);
	
	if (exists($RunArguments{$TempArgs[0]}))  {
		$RunArguments{$TempArgs[0]} = $TempArgs[1];
	}
}

my $MinReads = $RunArguments{MinReads};



#############################################################################################################
#Get names of all samples in the analysis, and store them in array AllSampleNames
#Omit any samples that did not have any reads assigned to them.

my @OmittedSamples = ();  #These are samples that are in the MasterBarcodeFile, but did not have any unique reads assigned to them.
my @AllSampleNames = ();  #All samples with reads assigned to them.

open CURRENTBARCODEFILE, "TempFiles/MasterBarcodeFile.txt" or die$!;

my $TotalNumberOfIndividuals = 0;

while (<CURRENTBARCODEFILE>)  {
	chomp ($_);
	my @TabSeparatedArray = split (/\t/, "$_");
			
	if (-e "TempFiles/ForBinomialTest$TabSeparatedArray[1].txt")  {
		push (@AllSampleNames, $TabSeparatedArray[1]);
		$TotalNumberOfIndividuals++;
	}	
	
	else {
		push(@OmittedSamples, $TabSeparatedArray[1]);
	}	
}

close CURRENTBARCODEFILE;




############################################################################################################
############################################################################################################
#For each individual, run R script on each pair of alleles at each locus and use binomial test to genotype.
#Whether a given locus is genotyped in a specific individual depends on whether the number of reads for that individual
#at that locus exceeds a certain threshold (MinReads above).  The default threshold is 10, but that can be changed with a command line argument.
#Print scored genotypes to file Genotypes.txt
############################################################################################################
############################################################################################################

#First, update the Genotype.R template script to set the desired coverage threshold.
 
open GENOTYPESFILE, ">TempFiles/Genotypes.txt" or die$!;
open GENOTYPERSCRIPT, "RScripts/Genotype.R" or die$!;
open GENOTYPERSCRIPTEDIT, ">RScripts/Genotype_Edit.R" or die$!;
 
 
while(<GENOTYPERSCRIPT>)  {
	 if ($_ =~ /NumTrials<5/) {
 	 	 print GENOTYPERSCRIPTEDIT "if (NumTrials<$MinReads) {\n";
 	 }
	
 	 else {
 	 	 print GENOTYPERSCRIPTEDIT "$_";
 	 }
}	 
 


############################################################################################################
print "Scoring genotypes at all nonparalogous loci.\n\n";
print "Currently genotyping sample...";
 
my $FirstIndividual = 1;

foreach my $f (@AllSampleNames)  {
     
 	 if (-e "TempFiles/ForBinomialTest$f.txt")  {
 	 
 	 	 print "$f\t";
 	 
 	 	 open LOCIFILE, "TempFiles/ForBinomialTest$f.txt" or die$!;
 	 	 open TEMPLOCIFILE, ">TempFiles/TempBiallelicLociForGenotyping.txt" or die$!;
	 
 	 	 while (<LOCIFILE>)  {
 	 	 	 print TEMPLOCIFILE "$_";
 	 	 }
	 
		close LOCIFILE;
		close TEMPLOCIFILE;
	 
		system "R --vanilla --slave < RScripts/Genotype_Edit.R";  	
	 
	 
	 
		if ($FirstIndividual == 1)  {		#If first individual, print the locus names to file TempGenotypes.txt before moving to the genotypes for this individual.
			open TEMPGENOTYPES, "TempGenotypes.txt" or die$!;
			print GENOTYPESFILE "\t";
	   
			while (<TEMPGENOTYPES>)  {
				if ($_ =~ /Locus/)  {
					chomp ($_);
					print GENOTYPESFILE "$_\t";
				}
			}  
			close TEMPGENOTYPES;
			$FirstIndividual = 0;
			print GENOTYPESFILE "\n";
		} 
	  
	 
	 
		open TEMPGENOTYPES, "TempGenotypes.txt" or die$!;
		my $LineCounter = 0;
		print GENOTYPESFILE "Individual$f\t";
	 
		while (<TEMPGENOTYPES>)  {	#print the first allele at each locus for the current individual to file Genotypes
			$LineCounter++;
	   
			if ($LineCounter == 2)  {
				chomp ($_);
				print GENOTYPESFILE "$_\t";
	     		}
	   
	     		if ($LineCounter == 3)  {
	     			$LineCounter = 0;
	     		}
	     	}
	     	
	     	print GENOTYPESFILE "\n";
	     	close TEMPGENOTYPES;
	 
	 
	     	open TEMPGENOTYPES, "TempGenotypes.txt" or die$!;
	     	$LineCounter = 0;
	     	print GENOTYPESFILE "Individual$f\t";
	       
	     	while (<TEMPGENOTYPES>)  {	#print the second allele at each locus for the current individual to file Genotypes
	     		$LineCounter++;     
	   
	     		if ($LineCounter == 3)  {
	     			chomp ($_);
	     			print GENOTYPESFILE "$_\t";
	     			$LineCounter = 0;
	     		}
	     	}
	     	
	     	print GENOTYPESFILE "\n";
 
	     	system "rm TempGenotypes.txt";
 
	 } 
 }
 
 close GENOTYPESFILE;
 


###########################################################################################################
###########################################################################################################
##Evaluate for potentially bad individuals (# of NA's in SNPMatrixAll is > 2 stdev above mean).
###########################################################################################################
###########################################################################################################
 
#First, create SNPMatrixAll, which has every polymorphic locus not identified as paralogous - doesn't matter how many individuals it was scored in.

system "R --vanilla --slave < RScripts/OutputSNPMatrixAll.R";


###########################################################################################################
#Get the number of NA's for each individual and store it in array NACounts
print "Checking for individuals with large amounts of missing data (have >2 StDev more missing data than the average)\n";
system "mkdir Output/Genotypes";

open SNPMATRIX, "TempFiles/SNPMatrixAll.txt" or die$!;

my $Starter = 0;
my @SampleNames = ();
my @NACounts = ();
my $OddNumberLine = 1;
my %AllLocusNames = ();
my @AllLocusNamesArray = ();
my $NumOfLoci = 0;

while (<SNPMATRIX>)  {
	
	#Get count of total number of unique polymorphic loci in the dataset.
	
	
	if ($Starter == 0)  {	#on the first line (locus names)
		$Starter++;
		@AllLocusNamesArray = split(/\t/,$_);
		
		for my $name (@AllLocusNamesArray)  {
			if (exists($AllLocusNames{$name}))  {
				next;
			}
			
			else {
				$NumOfLoci++;
				$AllLocusNames{$name} = 1;
			}	
		
		}
	}
	
	
	

	else {			#On a line with genotypes for one of the samples.  Count number of loci with NA's.
	
	    my %LociWithNAs = ();
		
	    if ($OddNumberLine == 1)  {	
		
	    	my $TempNACount = 0;
		chomp($_);
		my @CurrentGenotypes = split (/\t/, $_);
		push (@SampleNames, $CurrentGenotypes[0]);
		
		my $CurrentLocationInArray = 1;
		my $CurrentGenotypesLength = @CurrentGenotypes;
		
		foreach my $genotype (@CurrentGenotypes[1..$CurrentGenotypesLength-1]) {
			
			if ($genotype =~ /NA/)  {
				
				my $CurrentLocus = $AllLocusNamesArray[$CurrentLocationInArray];
				
				if (exists($LociWithNAs{$CurrentLocus}))  {	#make sure that loci that have multiple SNPs only get counted once if they have NA.
					$CurrentLocationInArray++;
					next;
				}
				
				else {
					$LociWithNAs{$CurrentLocus} = 1;
					$TempNACount++;
					$CurrentLocationInArray++;
				}
			}
		}
		
		push (@NACounts, $TempNACount);
		$TempNACount = 0;
		
		$OddNumberLine = 0;
		
	    }
		
	    else {
			$OddNumberLine = 1;
	    }
	}
}




###########################################################################################################
#Get the proportion of missing data for each individual and print it to file MissingData.txt.

my @NAProportions;
my $SampleElementCounter = 0;

for my $count (@NACounts)  {
	
	my $TempProportion = $count/$NumOfLoci;
	push (@NAProportions, $TempProportion);
}

open NAPROPORTIONSFILE, ">Output/RunInfo/MissingDataProportions.txt" or die$!;

for my $name (@SampleNames)  {
	
	print NAPROPORTIONSFILE "$name\t";
	print NAPROPORTIONSFILE "$NAProportions[$SampleElementCounter]\n";
	$SampleElementCounter++;
	
}	




##############################################################################################################################################################################		
#Get the mean and stdev of the NACount values

my $NumOfIndividuals = @NACounts;

my $TotalNACount = 0;

foreach my $count (@NACounts)  {
	$TotalNACount = $TotalNACount + $count;
}

my $MeanCount = $TotalNACount/$NumOfIndividuals;

my @SquaredDifferences = ();

foreach my $count (@NACounts) {
	my $TempDifference = $count - $MeanCount;
	my $SquaredDifference = $TempDifference*$TempDifference;
	push (@SquaredDifferences, $SquaredDifference);
}

my $SumSquaredDifferences = 0;

foreach my $SquaredDifference (@SquaredDifferences)  {
	$SumSquaredDifferences = $SumSquaredDifferences + $SquaredDifference;
}

my $MeanSquaredDiff = $SumSquaredDifferences/$NumOfIndividuals;

my $StDev = sqrt($MeanSquaredDiff);

close SNPMATRIX;


#############################################################################################################################################################################		
#Identify individuals with >2 stdev more missing data than the mean.

open FLAGGEDSAMPLES, ">TempFiles/FlaggedSamples.txt" or die$!;
open GOODSAMPLES, ">TempFiles/GoodSamples.txt" or die$!;

my $BadSample = 0;
my $TwoStDev = 2*$StDev;
my $NAThresholdHigh = $MeanCount+$TwoStDev;
my $CurrentSample = 0;
my @BadSamples = ();
my $CurrentIndividualNumber = 0;

open NACOUNTSTOPLOT, ">TempFiles/NACountsToPlot.txt" or die$!;
open SAMPLENAMESTOPLOT, ">TempFiles/NASampleNamesToPlot.txt" or die$!;
open NACOUNTS, ">TempFiles/NACounts.txt" or die$!;

foreach my $name (@SampleNames)  {
	print SAMPLENAMESTOPLOT "$name\t";
	print NACOUNTS "$name\t";
	print NACOUNTS "$NACounts[$CurrentIndividualNumber]\n";
	$CurrentIndividualNumber++;
}	

foreach my $count (@NACounts)  {
	print NACOUNTSTOPLOT "$count\t";
	
	$BadSample = 0;
	
	if ($count > $NAThresholdHigh)  {	#Current sample has >2 stdev more missing data than the mean.
		$BadSample = 1;
	}

	if ($BadSample == 1)  {
		push (@BadSamples, $SampleNames[$CurrentSample]);
		my $TempSample = $SampleNames[$CurrentSample];
		$TempSample =~ s/"//g;
		print FLAGGEDSAMPLES "$TempSample\n";
	}

	$BadSample = 0;
	$CurrentSample++;
}	

close NACOUNTSTOPLOT;
close SAMPLENAMESTOPLOT;
close FLAGGEDSAMPLES;

system "R --vanilla --slave < RScripts/PlotNACounts.R";






############################################################################################################################
#Determine whether any samples will be left out of further analyses.  
#The script makes suggestions about potential bad samples, but the user makes the final decision.

open REMOVEDSAMPLES, ">Output/RunInfo/MasterReport.txt" or die$!;

if ($OmittedSamples[0])  {
	print REMOVEDSAMPLES "Samples @OmittedSamples were omitted from the analysis because no unique reads were assigned to them.\n\n";
}

print REMOVEDSAMPLES "A total of $TotalNumberOfIndividuals individuals were analyzed.\n\n";



my %SamplesToRemove = ();

if (@BadSamples)  {
	print "\n\nSamples identified as potentially bad samples are @BadSamples.\n\n";
	
	print "Do you want to remove all(a), some(s), or none(n) of these potentially bad samples from the analysis? (a/s/n)\n";
	my $Remove = <STDIN>;
	chomp($Remove);
	
	my %BadNamesHash = ();
	my @BadSamplesUpdate = ();

	if ($Remove =~ /s/)  {
		
		 print "Enter the names of the samples you want to remove. Separate each with a tab\n";
		 my $RemoveString = <STDIN>;
		 chomp($RemoveString);
		
		 if ($RemoveString =~ /\t/)  {
		 
		 	 my @SamplesToRemove = split(/\t/, $RemoveString);
		  
		
		 	 foreach my $name (@SamplesToRemove)  {
		 	 	 $name =~ s/Individual//;
		 	 	 $SamplesToRemove{$name} = 1;
		 	 }
		 }
		 
		 else {
		 	 $RemoveString =~ s/Individual//;
		 	 $SamplesToRemove{$RemoveString} = 1;
		 }	 
		
	}
		 
		 
	elsif ($Remove =~ /a/)  {	 
		 
		foreach my $badsample (@BadSamples)  {
			
			$SamplesToRemove{$badsample} = 1;
		}	
	}
	
	
	elsif ($Remove =~ /n/)  {
		print "All flagged samples will be retained for analyses.\n";
	}

	else {
		print "Unrecognized input (a/s/n).  Samples identified as bad will be omitted from further analyses.\n"; 
	
		foreach my $badsample (@BadSamples)  {
			
			$SamplesToRemove{$badsample} = 1;
		}
	}	 
		 
}


if (@BadSamples)  {
	
	print "Are there any additional samples you would like to remove from the analysis? (y/n)\n";
	
	my $AdditionalRemove = <STDIN>;
	chomp($AdditionalRemove);
	
	my $AdditionalRemoveString;
	
	if ($AdditionalRemove =~ /y/)  {
		print "Enter the names of the samples you want to remove. Separate each with a tab\n";
		$AdditionalRemoveString = <STDIN>;
		chomp($AdditionalRemoveString);
		
	        my @AdditionalRemoves = split(/\t/, $AdditionalRemoveString);

	        foreach my $AddRemove (@AdditionalRemoves)  {
	           	
	           $AddRemove =~ s/Individual//;	
		   $SamplesToRemove{$AddRemove} = 1;
	        }
	}
}

else {
	
	print "No samples were flagged as potentially bad samples.  Would like to remove any samples from further analyses anyway? (y/n)\n";
	
	my $AdditionalRemove = <STDIN>;
	chomp($AdditionalRemove);
	
	my $AdditionalRemoveString;
	
	if ($AdditionalRemove =~ /y/)  {
		print "Enter the names of the samples you want to remove. Separate each with a tab\n";
		$AdditionalRemoveString = <STDIN>;
		chomp($AdditionalRemoveString);
		
	        my @AdditionalRemoves = split(/\t/, $AdditionalRemoveString);

	        foreach my $AddRemove (@AdditionalRemoves)  {
	           	
	           $AddRemove =~ s/Individual//;	
		   $SamplesToRemove{$AddRemove} = 1;
	        }
	}
	
	
	elsif ($AdditionalRemove =~ /n/) {
		
		print "All individuals will be analyzed.\n";
		print REMOVEDSAMPLES "No bad samples identified in the dataset. All were analyzed";
	
	}	

}
	




############################################################################################################################
#Get rid of samples identified as bad by the user.
#Go through array AllSampleNames and remove the names that are in SamplesToRemove hash.
#Retained individuals will be stored in array called @GoodSampleNames.  These are also printed to file TempFiles/GoodSamples.txt.

my @GoodSampleNames;
my %SamplesToRemoveUpdate;
my $NumberSamplesRemoved = 0;

if (%SamplesToRemove)  {
	
	for (keys %SamplesToRemove)  {
		$_ =~ s/"//g;
		$_ =~ s/Individual//;
		
		$SamplesToRemoveUpdate{$_} = 1;
	}	
		

	foreach my $name (@AllSampleNames)  {
		  if (exists($SamplesToRemoveUpdate{$name})) {
			  $NumberSamplesRemoved++;	
		  	  next;
		  }
		   
		  else {	
			push (@GoodSampleNames, $name);
		  }
	}

	
	print "The samples that have been eliminated from further analyses are...\n";
	
	print REMOVEDSAMPLES "You chose to remove $NumberSamplesRemoved of the $TotalNumberOfIndividuals samples prior to genotyping. ";

	print REMOVEDSAMPLES "The samples removed from analyses were...\n";
  
	for (keys %SamplesToRemoveUpdate)  {
		print "$_\n";
		print REMOVEDSAMPLES "$_\n";
	}

}


else  {
	
	foreach my $name (@AllSampleNames)  {
		push (@GoodSampleNames, $name);
	}
	
	print "All samples were included in analyses.\n";
	print REMOVEDSAMPLES "No samples were removed from the analyses prior to genotyping.\n";

			
}
	



foreach my $GoodSample (@GoodSampleNames)  {
	chomp($GoodSample);
	print GOODSAMPLES "$GoodSample\n";
}	

close REMOVEDSAMPLES;
close GOODSAMPLES;




#######################################################################################################################
#######################################################################################################################
#Based on the retained samples, identify monomorphic loci.
#These are all of the reads stored in the ErrorTestOut file that are not part of a polymorphic locus, or a paralogous locus.
#######################################################################################################################
#######################################################################################################################

#Get all unique locus names that are polymorphic after binomial tests and not paralogous - put them in array UniqueLoci
#Will use these to identify the reads that are part of a polymorphic locus.

open SNPMATRIX, "TempFiles/SNPMatrixAll.txt" or die$!;

my $Counter = 0;
my @UniqueLoci = ();
my %UniqueLocusNames = ();

while (<SNPMATRIX>)  {
	
	if ($Counter == 0)  {	#We're on the first line (locus names) of the file

		$_ =~ s/"//g;
		chomp($_);
		my @TotalLocusNames = split (/\t/, "$_");
		shift (@TotalLocusNames);	#Get rid of blank element at beginning
		
		
		foreach my $name (@TotalLocusNames)  {	#populate the hash UniqueLocusNames with the locus names and counts of each
			
			if (exists($UniqueLocusNames{$name})) {
			
				$UniqueLocusNames{$name}++;
			}
			
			else {			#It's a new locus name - push the location to NumbersWanted and the name to UniqueLoci.
				$UniqueLocusNames{$name} = 1;
				push (@UniqueLoci, $name);
			}
		}
		
		$Counter++;
		
	}

	
	
	else {	
		last;

	}
}

#close NODUPSOUT;
close SNPMATRIX;




##############################################################################################
#Check each locus name in the first RawReadCounts_NonParalogous file and see if it's in the array UniqueLoci.  If so, print that locus
#with it's reads to RawReadCounts_NonParalogousAllPoly file
#This is necessary because some loci in the RawReadCounts_NonParalogous file may actually be monomorphic after the genotyping was done.  
#For example, say an error read had a read depth of 10 in a single individual, at an otherwise monomorphic locus.  The read depth for
#the true sequence was 150 for this individual.  It has two alleles in the RawReadCounts_NonParalogous file, but after the binomial test,
#the error read is removed, and now it's a monomorphic locus.  
#The RawReadCounts_NonParalogousAllPoly has these loci eliminated, because they don't exist in the SNPMatrixAll file, and therefore, don't get in the array UniqueLoci.


if (-e "TempFiles/RawReadCountFiles/RawReadCounts_NonParalogous$GoodSampleNames[0].txt") {

	open RAWGENOSREAD, "TempFiles/RawReadCountFiles/RawReadCounts_NonParalogous$GoodSampleNames[0].txt" or die$!;
	open RAWGENOSWRITE, ">TempFiles/RawReadCounts_NonParalogousAllPoly$GoodSampleNames[0].txt" or die$!;
}

elsif (-e "TempFiles/RawReadCountFiles/RawReadCounts_NonParalogous$GoodSampleNames[1].txt") {	#in case the first one doesn't exist

	open RAWGENOSREAD, "TempFiles/RawReadCountFiles/RawReadCounts_NonParalogous$GoodSampleNames[1].txt" or die$!;
	open RAWGENOSWRITE, ">TempFiles/RawReadCounts_NonParalogousAllPoly$GoodSampleNames[1].txt" or die$!;
}

else {				#in case the first two don't exist - this is probably unnecessary now that samples with no data are automatically omitted from the dataset.
	open RAWGENOSREAD, "TemwpFiles/RawReadCountFiles/RawReadCounts_NonParalogous$GoodSampleNames[2].txt" or die$!;
	open RAWGENOSWRITE, ">TempFiles/RawReadCounts_NonParalogousAllPoly$GoodSampleNames[2].txt" or die$!;
}
	

$Starter = 0;
my $PreviousLocus;
my $LastPrinted = 0;
my @CurrentSeqsAndCounts;


while(<RAWGENOSREAD>)  {
	
	chomp($_);
	
	if ($Starter == 0)  {
		
		$PreviousLocus = $_;
		$Starter++;

	}	

	
	else  {
		
		if ($_ =~ /Locus/)  {
		
			foreach my $LocusName (@UniqueLoci)  {
				
				if ($PreviousLocus eq $LocusName)  {
					
					print RAWGENOSWRITE "$PreviousLocus\n";
					
					foreach my $line (@CurrentSeqsAndCounts)  {
						print RAWGENOSWRITE "$line\n";
					}
					
					last;
				}
				
				
			}
			
			$PreviousLocus = $_;
			$LastPrinted = 1;
			@CurrentSeqsAndCounts = ();
			
		}
		
		else {
			push (@CurrentSeqsAndCounts, $_);
			$LastPrinted = 0;
			
		}	
		
	}	

}


if ($LastPrinted == 0)  {
	
	
		foreach my $LocusName (@UniqueLoci)  {
				
				if ($PreviousLocus eq $LocusName)  {
					
					foreach my $line (@CurrentSeqsAndCounts)  {
						print RAWGENOSWRITE "$line\n";
					}
					
					last;
				}
				
				
			}
			
			$PreviousLocus = $_;
			$LastPrinted = 1;
			@CurrentSeqsAndCounts = ();


}


close RAWGENOSREAD;
close RAWGENOSWRITE;






#######################################################################################################################
#######################################################################################################################
#Identify monomorphic loci.  Create a hash from the IndividualRawGenotypeFileAllPoly file.  Keys will be the sequences.
#Search all of the reads in ErrorTestOut.txt against the keys of this hash.  
#ErrorTestOut contains all of the reads across the entire dataset that were retained as non-error reads.
#If the read don't exist in the hash, print to file MonomorphicLoci.txt.

print "Identifying monomorphic loci.\n";

open MONOMORPHICLOCI, ">TempFiles/MonomorphicLoci.txt" or die$!;
open ERROROUT, "TempFiles/ErrorReadTest/ErrorTestOut.txt" or die$!;

my $FirstName = $GoodSampleNames[0];

open RAWGENOTYPES, "TempFiles/RawReadCounts_NonParalogousAllPoly$FirstName.txt" or die$!;

my @SeqsAndCountsForHash;

while (<RAWGENOTYPES>)  {
	
	chomp($_);
	
	if ($_ !~ /[ATGC]/)   {
		next;
	}
	
	else {
		my @TempArray = split(/\t/, $_);
		
		my $SeqToRemoveDashes = $TempArray[0];
		$SeqToRemoveDashes =~ s/-//g;
		my $SeqWODashes = $SeqToRemoveDashes;
		push (@SeqsAndCountsForHash, $SeqWODashes);
		push (@SeqsAndCountsForHash, $TempArray[1]);	
	}
}

close RAWGENOTYPES;




my %PolymorphicSeqs = @SeqsAndCountsForHash;
my $keyscounter = 0;

for my $key (keys(%PolymorphicSeqs)) {
     $keyscounter++;
}

while(<ERROROUT>) {
	chomp($_);
	if (exists $PolymorphicSeqs{$_}) {
		next;
	}
	
	else {
		print MONOMORPHICLOCI "$_\n";
	}
}


close MONOMORPHICLOCI;
close ERROROUT;


########################################################################################
#MonomorphicLoci file currently contains all reads that were part of loci identified as paralogous.  Remove all of these.

#First, put all of the paralogous reads in a hash without any dashes.

open PARALOGOUSLOCI, "TempFiles/ParalogousLoci.txt" or die$!;

my %Paralogs;

while (<PARALOGOUSLOCI>)  {
	
	chomp($_);
	
	if ($_ =~ /[ATGC]/)  {
		my @TempArray = split(/\t/, $_);
		my $TempRead = $TempArray[0];
		$TempRead =~ s/-//g;
		
		$Paralogs{$TempRead} = 1;
	}
}

close PARALOGOUSLOCI;

#Now, check reads in MonomorphicLoci to make sure they don't occur in Paralogs hash.  If they don't, print them to file MonomorphicsNoParalogs.

open MONOMORPHICS, "TempFiles/MonomorphicLoci.txt" or die$!;
open MONOMORPHICSNOPARALOGS, ">TempFiles/MonomorphicsNoParalogs.txt" or die$!;

while (<MONOMORPHICS>)  {
	
	chomp($_);
	
	if (exists $Paralogs{$_})  {
		
		next;
	}

	else {
		print MONOMORPHICSNOPARALOGS "$_\n";
	}	
}


close MONOMORPHICS;
close MONOMORPHICSNOPARALOGS;



########################################################################################
#Add counts for each individual to monomorphic loci file - new file called "MonomorphicLociWCounts.txt"

my $Number = 0;
my $IndividualCounter = 0;

my $FinalNumber;

foreach my $Individual (@GoodSampleNames) {
	
	if (-e "TempFiles/UniqueWithCountsIndividual$Individual.txt")  {	
		$Number++;
		my $NumberPlus1 = $Number+1;
	
		if ($IndividualCounter == 0) {
		
			$IndividualCounter++;
			open CURRENTINDIVIDUAL, "TempFiles/UniqueWithCountsIndividual$Individual.txt" or die$!;
			my @CurrentIndividualArray = ();
		
			while (<CURRENTINDIVIDUAL>)  {
		    
				if ($_ =~ /[a-zA-Z]/) {	
					chomp($_);
					$_ =~ s/^\s*//;
					my @TempArray = split (/\s/, $_);
					push (@CurrentIndividualArray, $TempArray[1]);
					push (@CurrentIndividualArray, $TempArray[0]);
				}
			}	
	
			my %TempHash = @CurrentIndividualArray;
	
			open MONOMORPHICSEQS, "TempFiles/MonomorphicsNoParalogs.txt" or die$!;
			open MONOMORPHICUPDATE, ">TempFiles/MonomorphicUpdate$Number.txt" or die$!;
	
			while (<MONOMORPHICSEQS>) {
				chomp($_);
				my @TempArray = split (/\s+/, $_);
				my $CurrentSeq = $TempArray[0];
				my $Value = 0;
		
				if (exists($TempHash{$CurrentSeq})) {
					my $CurrentCount = $TempHash{$CurrentSeq};
					print MONOMORPHICUPDATE "@TempArray\t$CurrentCount\n";
				}
		   
				else {
					print MONOMORPHICUPDATE "@TempArray\t0\n";
				}	
			}
	
			close MONOMORPHICSEQS;
			close MONOMORPHICUPDATE;
		close CURRENTINDIVIDUAL;
	
		}	

		else {
		
			open CURRENTINDIVIDUAL, "TempFiles/UniqueWithCountsIndividual$Individual.txt" or die$!;
			my @CurrentIndividualArray = ();
		
			while (<CURRENTINDIVIDUAL>)  {
				if ($_ =~ /[a-zA-Z]/) {	
					chomp($_);
					$_ =~ s/^\s*//;
					my @TempArray = split (/\s/, $_);
					push (@CurrentIndividualArray, $TempArray[1]);
			    push (@CurrentIndividualArray, $TempArray[0]);
			    	}
			}	
	
			my %TempHash = ();
			%TempHash = @CurrentIndividualArray;
 
			my $NumberMinus1 = $Number-1;	
		
			open MONOMORPHICUPDATE, "TempFiles/MonomorphicUpdate$NumberMinus1.txt" or die$!;
			open MONOMORPHICWRITE, ">TempFiles/MonomorphicUpdate$Number.txt" or die$!;
			$FinalNumber = $Number;
		
			while (<MONOMORPHICUPDATE>) {
				chomp($_);
				$_ =~ s/\s/\t/;
				my @TempArray = split (/\s+/, $_);
				my $CurrentSeq = $TempArray[0];
				my $Value = 0;
		
				if (exists($TempHash{$CurrentSeq})) {
					my $CurrentCount = $TempHash{$CurrentSeq};
					print MONOMORPHICWRITE "@TempArray\t$CurrentCount\n";
				}
		
				else {
					print MONOMORPHICWRITE "@TempArray\t0\n";
				}	
			}
	
			close MONOMORPHICUPDATE;
			close MONOMORPHICWRITE;
			close CURRENTINDIVIDUAL;
	
		}
	
	}	
}



########################################################################################
#Parse out the Monomorphic loci into two files.
#First file contains those scored in all individuals (have the minimum genotyping threshold of reads that is used in Genotypes.R).
#Second file contains those not scored in all individuals, based on the threshold above.  This one includes the counts for each individual.


open MONOMORPHICSWITHCOUNTS, "TempFiles/MonomorphicUpdate$FinalNumber.txt" or die$!;
open MONOMORPHICINALL, ">Output/Genotypes/MonomorphicsScoredInAll.txt" or die$!;
open MONOMORPHICWITHMISSING, ">Output/Genotypes/MonomorphicLociNotScoredInAll.txt";


while (<MONOMORPHICSWITHCOUNTS>)  {
	my $MissingOne = 0;
	
	chomp($_);
	my @TempArray = split (/\s+/, $_);
	my $CurrentNumElements = @TempArray;
	
	foreach my $value (@TempArray[1..$CurrentNumElements-1])  {
		
		if ($value <= 5)  {
			$MissingOne = 1;
			last;
		}
	}		
			
	if ($MissingOne == 0)  {
		print MONOMORPHICINALL "$TempArray[0]\n";
	}

	else {
		
		foreach my $element (@TempArray)  {
			print MONOMORPHICWITHMISSING "$element\t";
		}
		print MONOMORPHICWITHMISSING "\n";
	}	
}

close MONOMORPHICSWITHCOUNTS;
close MONOMORPHICINALL;
close MONOMORPHICWITHMISSING;

system "rm TempFiles/MonomorphicUp*";





#######################################################################################################

#Get summary of numbers of loci


my $MonomorphicsScoredInAllCount;	#Line count from MonomorphicsScoredInAll.txt
my $MonomorphicsNotInAllCount;		#Line count from MonomorphicLociNotScoredInAll.txt
my $TotalPolymorphicCountNonParalogous;	#From unique locus names in SNPMatrixAll.txt
my $ParalogousLoci;			#Line count from ParalogousLoci.txt


open MASTER, ">>Output/RunInfo/MasterReport.txt" or die$!;
print MASTER "\n\n";

print MASTER "Total number of monomorphic loci scored in all individuals genotyped is\t";
system "wc -l Output/Genotypes/MonomorphicsScoredInAll.txt | tee -a Output/RunInfo/MasterReport.txt";
print MASTER "\n";

print MASTER "Total number of monomorphic loci not scored in all individuals is\t";
system "wc -l Output/Genotypes/MonomorphicLociNotScoredInAll.txt | tee -a Output/RunInfo/MasterReport.txt";
print MASTER "\n";

open PARALOGOUS, "TempFiles/ParalogousLoci.txt" or die$!;
my $NumParalogous = 0;

while (<PARALOGOUS>)  {
	if ($_ =~ /^Locus/) {
		$NumParalogous++;
	}
}	


print MASTER "Total number of paralogous loci identified and removed is\t$NumParalogous\n";

open SNPMATRIXALL, "TempFiles/SNPMatrixAll.txt" or die$!;

my $SNPMatrixAllCounter = 1;
my %PolymorphicNamesUnique;

while(<SNPMATRIXALL>)  {
	
	if ($SNPMatrixAllCounter==1)  {
		
		$_ =~ s/"//g;
		
		my @TempArray = split(/\t/,$_);
		
		shift(@TempArray);
		
		foreach my $name (@TempArray)  {
			
			$PolymorphicNamesUnique{$name} = 1;
		}
		
		last;
	}
	
}

my $HashSize = scalar keys %PolymorphicNamesUnique;


print MASTER "Total number of polymorphic loci identified is\t$HashSize";
print MASTER "\n";

close MASTER;
close SNPMATRIXALL;




#Get mean/median read counts per individual/locus.


#First, create hash (AllSeqs) that contains all reads from one of the NonParalogousRawGenotypes files (this already exists - %PolymorphicSeqs), then add all monomorphic seq reads scored in all samples to this hash.

open MONOALL, "Output/Genotypes/MonomorphicsScoredInAll.txt" or die$!;

my %AllSeqs = %PolymorphicSeqs;

while (<MONOALL>)  {
	chomp($_);
	
	if ($_ =~ /[ATGC]/) {
	    $AllSeqs{$_} = 1;
	} 
}	

close MONOALL;


#Next, add the monomorphic seqs not scored in all samples to the hash AllSeqs.

open MONONOTALL, "Output/Genotypes/MonomorphicLociNotScoredInAll.txt" or die$!;

while (<MONONOTALL>)  {
	chomp($_);
	
	if ($_ =~ /[ATGC]/) {
	    
		my @TempArray = split(/\t/, $_);
		my $CurrentSeq = $TempArray[0];
		
		$AllSeqs{$CurrentSeq} = 1;
	}	
	 
		

}	
close MONONOTALL;











#For each line in AllReadsAndDepths, see if the seq is in the AllSeqs hash (which doesn't include paralogous loci).  If so, push all of the non-zero counts associated with the seq to an array.
#There are a couple of problems here - first, it's not accounting for individuals that were removed from the analysis, as they are still in the VarianceFinal file.  Maybe print a new file that doesn't include these?
#Also, this counts loci that might not have been genotyped at all, because the read counts were too low.  However, since we haven't run Polymorphics yet, can't reference against the locus names of a Haplotypes file (maybe should do this?)

my @TotalCounts = ();
my $SampleSize = 0;
my $Sum = 0;

open VARFILE, "TempFiles/ErrorReadTest/AllReadsAndDepths.txt" or die$!;

while (<VARFILE>)  {
	chomp($_);
	my @TempArray = split(/\t/, $_);
	my $CurrentSeq = $TempArray[0];
	#print "$CurrentSeq.55";
	
	if (exists($AllSeqs{$CurrentSeq}))  {
		
		foreach my $a (@TempArray[1..$TotalNumberOfIndividuals])  {
			if ($a == 0)  {
				next;
			}
			
			else {
				push (@TotalCounts, $a);
				$SampleSize++;
			}
		}
	}
}


#Sum the values in the array and divide by the total length of the array.
#Also, print values to file to plot in R.

open TEMP, ">TempFiles/TempDepthsToPlot.txt" or die$!;

foreach my $count (@TotalCounts)  {
	
	print TEMP "$count\t";
	$Sum = $Sum+$count;
}

close TEMP;

open TEMP, "TempFiles/TempDepthsToPlot.txt" or die$!;
open DEPTHS, ">TempFiles/DepthsToPlot.txt" or die$!;

while (<TEMP>)  {
	$_ =~ s/\t$//;
	print DEPTHS "$_";
}

close TEMP;
close DEPTHS;
	

my $average = $Sum/$SampleSize;


#Print results to MasterReport file.
open MASTER, ">>Output/RunInfo/MasterReport.txt" or die$!;

print MASTER "\nThe average read depth across all polymorphic and monomorphic loci is $average\n";

my @SortedCounts = sort {$a <=> $b} @TotalCounts;

my $Median;

if ($SampleSize%2) {
	$Median=$SortedCounts[int($SampleSize/2)];
}

else {
	$Median = ($SortedCounts[($SampleSize/2)-1] + $SortedCounts[($SampleSize/2)-1])/2;
}	


print MASTER "\nThe median read depth across all polymorphic and monomorphic loci is $Median\n\n";



my $MinCount = $SortedCounts[0];
my $MaxCount = $SortedCounts[-1];

print MASTER "The minimum read count at a locus was $MinCount and the maximum count was $MaxCount\n"; 

close MASTER;
close VARFILE;


#Plot the read counts

#Edit PlotSNPLocations.R script to set x-axis

open RFILE, "RScripts/PlotReadCounts.R" or die$!;
open OUTFILE, ">RScripts/PlotReadCountsEdit.R" or die$!;

while(<RFILE>) {
	if ($_ =~ /^MaxLength/)  {
		print OUTFILE "MaxLength<-$MaxCount\n";
	}
	
	else {
		print OUTFILE "$_";
	}
}

close RFILE;
close OUTFILE;


system "R --vanilla --slave < RScripts/PlotReadCountsEdit.R";



#Repeat, but don't include monomorphic loci.






