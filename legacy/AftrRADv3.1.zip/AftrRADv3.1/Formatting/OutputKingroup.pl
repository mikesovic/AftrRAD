#! /usr/bin/perl
use warnings;
use strict;


print "Enter the name of the haplotypes file to use\n";
my $FileName = <STDIN>;
chomp($FileName);


open HAPLOTYPES, "../Output/Genotypes/$FileName" or die$!;
open INFILE, ">Kingroup_Infile.txt" or die$!;

my $LineCounter = 0;
my @Array1;
my @Array2;

while(<HAPLOTYPES>)  {
	
	chomp($_);
	
	if ($_ =~ /Locus/)  {
		print INFILE "$_\n";
		next;
	}
	
	if ($LineCounter == 0) {
		
		@Array1 = split (/\t/, $_);
		$LineCounter=1;
		next;
	}	
	
	if ($LineCounter == 1)  {
		
		
		@Array2 = split (/\t/, $_);
		$LineCounter=0;
		
		print INFILE "$Array1[0]\t";
		
		my $ArrayLength = @Array1;
		
		
		foreach my $value (1..$ArrayLength-1)  {
			
			
			if ($Array1[$value] =~ /NA/) {
				print INFILE "0\t";
			}	
			
			else {
				print INFILE "$Array1[$value]";
				print INFILE "/";
				print INFILE "$Array2[$value]\t";
			
			}
		}
		
		print INFILE "\n";
	}
}	
			
		
		
	
	

	
