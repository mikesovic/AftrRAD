LocationsToPlot<-scan(file="TempFiles/SNPLocationsToPlot.txt")
MaxLength<-100
MaxLength<-MaxLength+5
pdf("Output/RunInfo/SNPLocations.pdf")
hist(LocationsToPlot, breaks=seq(0,MaxLength,by=1))