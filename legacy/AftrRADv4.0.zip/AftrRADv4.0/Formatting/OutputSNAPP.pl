#! /usr/bin/perl
use warnings;
use strict;

my $FileName;


opendir GENOS, "../Output/Genotypes/";
my @AllFileNames = grep { $_ ne '.' && $_ ne '..' && $_ ne '.DS_Store' } readdir(GENOS);
close GENOS;

my @SNPFileNames = ();

for my $name (@AllFileNames)  {
	if ($name =~ /SNP/) {
		push (@SNPFileNames, $name);
	}
}

my $NumSNPFiles = @SNPFileNames;

if ($NumSNPFiles == 1)  {
	$FileName = $SNPFileNames[0];
}

else {
	print "The following SNPMatrix files are available in the Output/Genotypes directory...\n";
	for my $file (@SNPFileNames) {
		print "$file\n";
	}
	print "\nEnter the name of the SNPMatrix file you want to use to create the SNAPP infile\n";

	$FileName = <STDIN>;
	chomp($FileName);
}	


# print "Enter the name of the SNP matrix file (in Output/Genotypes directory) you want to use. Loci for SNAPP will be a subset of the loci in this file\n";
# my $FileName = <STDIN>;
# chomp($FileName);



#Clean up the names in SNPMatrix file.


open FILE, "../Output/Genotypes/$FileName" or die$!;
mkdir "TempFiles" unless (-d "TempFiles");
open OUTFILE, ">TempFiles/SNPMatrix_Edit.txt" or die$!;

while(<FILE>)  {
	$_ =~ s/Individual//;
	print OUTFILE "$_";
}

close FILE;
close OUTFILE;



##############################################################################################################################################
#Subset the SNPMatrix file as necessary to include the desired samples.

print "Do you want to include all (a) or a subset (s) of the individuals in the SNAPP infile? (a/s)\n";
my $AllOrSubset = <STDIN>;
chomp($AllOrSubset);

if ($AllOrSubset =~ /s/) {
	
	#Get the names of the individuals that will be included and store them as keys in hash SamplesWanted.
	print "Enter the name of a text file containing the names of the samples to include.\n";
	my $SampleFile = <STDIN>;
	chomp($SampleFile);

	my @SamplesWanted = ();

	open SAMPLESWANTED, "$SampleFile" or die$!;

	while (<SAMPLESWANTED>)  {
		chomp($_);
		push (@SamplesWanted, $_);
	}

	print "Samples included in SNAPP infile...@SamplesWanted\n\n";

	close SAMPLESWANTED;

	my %SamplesWanted;

	foreach my $sample (@SamplesWanted)  {
		$SamplesWanted{$sample} = 1;
	}

	
	#Go through SNPMatrix file and print the samples in the hash to file "SNAPP_Infile_NA.txt";
	open SNAPPFILE, ">TempFiles/General_Biallelics_Infile.txt" or die$!;
	open ALLSAMPLESFILE, "TempFiles/SNPMatrix_Edit.txt" or die$!;

	my $Counter = 0;

	while (<ALLSAMPLESFILE>)  {
	
		if ($Counter == 0)  {
			print SNAPPFILE "$_";
			$Counter++;
		
		}
	
		else {
			my @TempArray = split(/\t/, $_);
			if (exists($SamplesWanted{$TempArray[0]}))  {
				print SNAPPFILE "$_";
			}
		}		
	}

	close SNAPPFILE;
	close ALLSAMPLESFILE;

}
	

else {
	system "cp TempFiles/SNPMatrix_Edit.txt TempFiles/General_Biallelics_Infile.txt";

	
}






#Replace any NA's in file SNAPP_Infile_NA.txt with "N".

my $SnappCounter = 0;

open SNAPPFILEWITHNA, "TempFiles/General_Biallelics_Infile.txt" or die$!;
open SNAPPFILENONA, ">TempFiles/SingleSNPsAllRaw.txt" or die$!;

	while (<SNAPPFILEWITHNA>)  {
		chomp($_);	

		if ($SnappCounter == 0)  {
			$_ =~ s/"//g;
			$SnappCounter++;
			print SNAPPFILENONA "$_";
		}
		
		else {
			$_ =~ s/"//g;
			my @TempArray = split(/\t/, $_);
			my $Length = @TempArray;
			print SNAPPFILENONA "$TempArray[0]\t";
			
			foreach my $allele (@TempArray[1..$Length-1])  {
				$allele =~ s/NA/N/g;
				print SNAPPFILENONA "$allele\t";
			}
		}
		
		print SNAPPFILENONA "\n";
	}

close SNAPPFILEWITHNA;
close SNAPPFILENONA;




#Each line in SingleSNPsRaw ends with \t\n and has quotes.  Remove these.

open SNPFILE, "TempFiles/SingleSNPsAllRaw.txt" or die$!;
open SNPFILEUPDATE, ">TempFiles/SingleSNPsAll.txt" or die$!;
 
while (<SNPFILE>)  {
	$_ =~ s/\t\n$/\n/;
	$_ =~ s/"//g;
	print SNPFILEUPDATE "$_";
}
 
close SNPFILE;
close SNPFILEUPDATE;




#Run R script "OutputBiallelicSingleSNPs".  This outputs file "UnlinkedBiallelicSNPs_Raw.txt". A maximum of one SNP is output for each locus.
	
system "R --vanilla --slave < ../RScripts/OutputBiallelicSingleSNPs.R";








#Each line in UnlinkedBiallelicSNPs_Raw.txt ends with \t\n and has quotes.  Remove these.

open SNPFILE, "TempFiles/UnlinkedBiallelicSNPsRaw.txt" or die$!;
open SNPFILEUPDATE, ">TempFiles/UnlinkedBiallelicSNPs.txt" or die$!;
 
while (<SNPFILE>)  {
	$_ =~ s/\t\n$/\n/;
	$_ =~ s/"//g;
	print SNPFILEUPDATE "$_";
}
 
close SNPFILE;
close SNPFILEUPDATE;


	




#Run R Script OutputSNAPPMatrix.R.  This will convert the individuals to a single row with scores 0,1, or 2.

system "R --vanilla --slave < ../RScripts/OutputSNAPPMatrix.R";






open RAWMATRIX, "TempFiles/SNAPPMatrixRaw.txt" or die$!;
open SNAPPMATRIX, ">TempFiles/SNAPPMatrix.txt" or die$!;
 
while (<RAWMATRIX>)  {
	 
	$_ =~ s/"//g;
	print SNAPPMATRIX "$_";
}


#system "rm TempFiles/SNAPPMatrixRaw.txt";

close RAWMATRIX;
close SNAPPMATRIX;
 
 
open MATRIX, "TempFiles/SNAPPMatrix.txt" or die$!;
open NEXUSRAW, ">TempFiles/NexusRaw.txt" or die$!;
 
my $LineCounter2 = 0;
my @Allele1Array;
my @Allele2Array;
my $ArrayLength;
my $NumTaxa = 0;
 
while(<MATRIX>)  {
 
	#Skip the line with the locus names.
	
	if ($LineCounter2 == 0)  {
		$LineCounter2++;
		next;
	}

	#Store the first allele at each locus for the current individual in array "Allele1Array"
	elsif ($LineCounter2 == 1)  {
		 
		@Allele1Array = split (/\t/, $_);
		$LineCounter2 = 2;
		$ArrayLength = @Allele1Array;
		next;
	}
	 
	else {
		 
		#Store the second allele at each locus for the current individual in array "Allele2Array".
		@Allele2Array = split (/\t/, $_);
		$NumTaxa++;
		 
		
		my $LocusElement = 1;
		 
		print NEXUSRAW "$Allele1Array[0]\t";
		 
		foreach my $locus (@Allele1Array[1..$ArrayLength-1])  {
			 
			if ($locus =~ /N/)  {
				print NEXUSRAW "?";
			}	
			
			elsif (($locus == 0) && ($Allele2Array[$LocusElement] == 0))  {
				print NEXUSRAW "0";
			}
			 
			elsif (($locus == 1) && ($Allele2Array[$LocusElement] == 0))  {
				print NEXUSRAW "1";
			}
			 
			elsif (($locus == 0) && ($Allele2Array[$LocusElement] == 1))  {
				print NEXUSRAW "1";
			}
			 
			else {
				print NEXUSRAW "2";
			}
			 
			$LocusElement++;
		}
		 
		print NEXUSRAW "\n";
		 
		@Allele1Array = ();
		@Allele2Array = ();
			 
		$LineCounter2 = 1;
	}
}
 
close MATRIX;
close NEXUSRAW;


#Edit raw nexus file.

open NEXUSRAW, "TempFiles/NexusRaw.txt" or die$!;
open NEXUS, ">Beauti_Infile.nex" or die$!;
 
my $NumChar = $ArrayLength-1;
 
print NEXUS "#NEXUS\n\n";
print NEXUS "begin data;\n";
 
print NEXUS "dimensions\tntax=$NumTaxa\tnchar=$NumChar;\n";
print NEXUS "format\tdatatype=integerdata\tmissing=\"?\"\tsymbols=\"012\";\n";
print NEXUS "matrix\n";
 
while (<NEXUSRAW>)  {
	print NEXUS "$_";
}
 
print NEXUS ";\n";
print NEXUS "End;";
 
close NEXUS;
close NEXUSRAW;


system "rm TempFiles/*";
system "rmdir TempFiles";
