#! /usr/bin/perl
use warnings;
use strict;


print "Enter the proportion of individuals that must be genotyped in order to retain a locus (i.e. for 50 percent, enter 0.5).\n";
my $MinPercent = <STDIN>;
chomp ($MinPercent);

my $MinPercentMult = $MinPercent*100;



####################################################################################################


#Update the TotalBiallelicGenotypesLevels file to include only samples in the GoodSamples file.

open GOODSAMPLES, "TempFiles/GoodSamples.txt" or die$!;

my @TotalFileSampleNamesUpdate;

while (<GOODSAMPLES>)  {
	chomp($_);
	push (@TotalFileSampleNamesUpdate, $_);
}	

close GOODSAMPLES;

my %GoodNamesHash;

foreach my $GoodName (@TotalFileSampleNamesUpdate) {
	$GoodNamesHash{$GoodName} = 1;
}	

open GENOTYPES, "TempFiles/Genotypes.txt" or die$!;
open GENOTYPESUPDATE, ">TempFiles/GenotypesUpdate.txt" or die$!;
	
while (<GENOTYPES>)  {
	chomp($_);
	
	if ($_ =~ /Locus/)  {
		print GENOTYPESUPDATE "$_\n";
	}

	else  {	
	
	   my @TempArray = split("\t", $_);
	   my $FirstElement = $TempArray[0];
	   $FirstElement =~ s/Individual//;

	   if (exists($GoodNamesHash{$FirstElement}))  {
		
		print GENOTYPESUPDATE "$_\n";
	   }
	
	}
	
}	

close GENOTYPES;
close GENOTYPESUPDATE;




#####################################################################################################
####################################################################################################
#Pull out individual SNPs and get their locations along the read.
#####################################################################################################
#####################################################################################################

print "Identifying SNPs and determining the position of each SNP along the read.\n";

system "R --vanilla --slave < RScripts/OutputSNPMatrix.R";	#Outputs TempSNPMatrix.txt which has all SNPs in it and also SNPLocations.txt file, which has the position of each SNP along the read.



#####################################################################################################
#Plot frequency of SNP positions along the reads.  Give the option to remove SNPs after a certain position.


my @SNPLocationNames = ();
my @SNPLocationPositions = ();

open SNPLOCATIONS, "TempFiles/SNPLocations.txt" or die$!;		#This file is created by OutputSNPMatrix.R
open TEMP, ">TempFiles/TempLocationsToPlot.txt" or die$!;


while(<SNPLOCATIONS>)  {
	
	if ($_ =~ /^"V/)  {
		next;
	}

	elsif ($_ =~ /^"Locus"/)  {
		$_ =~ s/^"Locus" //;
		$_ =~ s/"//g;
		my @TempArray = split(/\s/,$_);
		foreach my $name (@TempArray)  {
			push (@SNPLocationNames, $name);
		}
	}

	else {
		$_ =~ s/^"SNPLocation" //;
		$_ =~ s/"//g;
		my @TempArray = split(/\s/,$_);
		foreach my $value (@TempArray)  {
			push (@SNPLocationPositions, $value);
			print TEMP "$value\t";
		}		
	}	

}


close TEMP;
close SNPLOCATIONS;



open TEMP, "TempFiles/TempLocationsToPlot.txt" or die$!;
open LOCATIONSTOPLOT, ">TempFiles/SNPLocationsToPlot.txt" or die$!;

my $LocationsCounter = 0;

while (<TEMP>)  {
	if ($LocationsCounter==0)  {
		$_ =~ s/\t$//;
		$LocationsCounter++;
		print LOCATIONSTOPLOT "$_\n";
	}

	else {	
		$_ =~ s/\t$//;
		print LOCATIONSTOPLOT "$_";
	}	
}

close TEMP;
close LOCATIONSTOPLOT;





#Now have edited the SNPLocations.txt file so that it can be read in to R and plotted.
#First, get read length to decide what the x-axis should be in the plot.

open READS, "TempFiles/AllUniquesSorted.txt" or die$!;
my $ReadLength;
my $ReadCounter = 0;

while (<READS>)  {
	if ($ReadCounter==1) {
		last;
	}

	$ReadLength = length($_);
	$ReadCounter++;
}

close READS;

#Edit PlotSNPLocations.R script to set x-axis

open RFILE, "RScripts/PlotSNPLocations.R" or die$!;
open OUTFILE, ">RScripts/PlotSNPLocationsEdit.R" or die$!;

while(<RFILE>) {
	if ($_ =~ /^MaxLength<-1/)  {
		print OUTFILE "MaxLength<-$ReadLength\n";
	}
	
	else {
		print OUTFILE "$_";
	}
}

close RFILE;
close OUTFILE;


system "R --vanilla --slave < RScripts/PlotSNPLocationsEdit.R";

#####################################################################################################


print "Check plot in file Output/RunInfo/SNPLocations.pdf.  If you want to remove SNPs after a specific read location, enter that location now.  Otherwise, enter '0'.\n";
my $MaxLocation = <STDIN>;
chomp($MaxLocation);


#####################################################################################################

#Get SNPs that occur before the threshold position.


if ($MaxLocation > 0)  {
	
	
	open RSCRIPT, "RScripts/MinNumber.R" or die$!;
	open RSCRIPTOUT, ">RScripts/MinNumberEdit.R" or die$!;

	while (<RSCRIPT>)  {
		#replace the line in this script with the entered threshold
		chomp($_);
	
		if ($_ =~ /^MinNumberAllelesGenotypedToRetainLocus/)  {
			print RSCRIPTOUT "MinNumberAllelesGenotypedToRetainLocus<-NumRowsInMatrix*$MinPercent\n";
		}
	
		elsif ($_ =~ /write.table\(SNPMatrixWithLociWith/)  {
				print RSCRIPTOUT "write.table(SNPMatrixWithLociWithMinGenotypes, file = \"Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp1.txt\", sep = \"\\t\",row.names=FALSE, col.names=FALSE)";
		}
		
		
	
		else {
			print RSCRIPTOUT "$_\n";
		}	
	}	

	close RSCRIPT;
	close RSCRIPTOUT;
	
	
	
	
	
	

	my @SitesToRetain = ();
	my $CurrentElementCounter = 0;

	foreach my $element (@SNPLocationPositions)  {
		$CurrentElementCounter++;
		if ($element < $MaxLocation)  {
			push (@SitesToRetain, $CurrentElementCounter)
		}
	}

	open SITESTOKEEP, ">TempFiles/SitesToRetain.txt" or die$!;

	foreach my $site (@SitesToRetain)  {
		print SITESTOKEEP "$site\t";
	}

	close SITESTOKEEP;

	system "R --vanilla --slave < RScripts/OutputSNPGoodLocations.R";
}

else {
	system "cp TempFiles/TempSNPMatrix.txt TempFiles/SNPMatrix_GoodLocations.txt";
	
	open RSCRIPT, "RScripts/MinNumber.R" or die$!;
	open RSCRIPTOUT, ">RScripts/MinNumberEdit.R" or die$!;

	while (<RSCRIPT>)  {
		#replace the line in this script with the entered threshold
		chomp($_);
	
		if ($_ =~ /^MinNumberAllelesGenotypedToRetainLocus/)  {
			print RSCRIPTOUT "MinNumberAllelesGenotypedToRetainLocus<-NumRowsInMatrix*$MinPercent\n";
		}
	
		elsif ($_ =~ /write.table\(SNPMatrixWithLociWith/)  {
				print RSCRIPTOUT "write.table(SNPMatrixWithLociWithMinGenotypes, file = \"Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp1.txt\", sep = \"\\t\",row.names=FALSE, col.names=FALSE)";
		}
	
		else {
			print RSCRIPTOUT "$_\n";
		}	
	}	

	close RSCRIPT;
	close RSCRIPTOUT;
}	

#####################################################################################################
#####################################################################################################

#Apply filter based on proportion of individuals that must be genotyped at each locus.

system "R --vanilla --slave < RScripts/MinNumberEdit.R";


###########################################################################################
#Remove dups in the SNPMatrix file and create haplotypes.

if ($MaxLocation == 0)  {
	open SNPMATRIXTEMP, "Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp1.txt" or die$!;
	
	open SNPMATRIX, ">Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp.txt" or die$!;
	
	my $Counter = 0;
	
	while(<SNPMATRIXTEMP>)  {
		if ($Counter == 0)  {
			my @TempArray = split(/\t/,$_);
			my $LocusNamesString = "\t";
			foreach my $name (@TempArray)  {
				if ($name !~ /L/)  {
					next;
				}
				
				else {
					$name =~ s/\..*/"/;
					$LocusNamesString = $LocusNamesString.$name;
					$LocusNamesString = $LocusNamesString."\t";
				}
			}
			$LocusNamesString =~ s/\t$//;
			print SNPMATRIX "$LocusNamesString";
			$Counter++;
		}
		
		else {
			print SNPMATRIX "$_";
		}
	}	
close SNPMATRIXTEMP;
close SNPMATRIX;
system "rm Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp1.txt";

}




else {
	open SNPMATRIXTEMP, "Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp1.txt" or die$!;
	
	open SNPMATRIX, ">Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp.txt" or die$!;
	
	my $Counter = 0;
	
	while(<SNPMATRIXTEMP>)  {
		if ($Counter == 0)  {
			my @TempArray = split(/\t/,$_);
			my $LocusNamesString = "\t";
			foreach my $name (@TempArray)  {
				if ($name !~ /L/)  {
					next;
				}
				
				else {
					$name =~ s/\..*/"/;
					$LocusNamesString = $LocusNamesString.$name;
					$LocusNamesString = $LocusNamesString."\t";
				}
			}
			$LocusNamesString =~ s/\t$//;
			print SNPMATRIX "$LocusNamesString";
			$Counter++;
		}
		
		else {
			print SNPMATRIX "$_";
		}
	}
	
close SNPMATRIXTEMP;
close SNPMATRIX;
system "rm Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp1.txt";

}






open NODUPSOUT, ">TempFiles/NoDupsOutHaplotypes.txt" or die$!;

if ($MaxLocation == 0)  {
	
	open SNPMATRIX, "Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp.txt" or die$!;
}

else {
	
	open SNPMATRIX, "Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp.txt" or die$!;
}	
	

my $Counter = 0;
my @NumbersWanted = ();		#Positions of the first instance of each unique locus
my @UniqueLoci = ();
my %UniqueLocusNames = ();	#Contains counts of the number of times each unique is repeated.

my @TotalLocusNames = ();

while (<SNPMATRIX>)  {
	
	if ($Counter == 0)  {	#We're on the first line (locus names) of the file

		my $CurrentElement = 0;
		$_ =~ s/"//g;
		chomp($_);
		@TotalLocusNames = split (/\t/, "$_");
		shift (@TotalLocusNames);	#Get rid of blank element at beginning
		
		foreach my $name (@TotalLocusNames)  {	#populate the hash UniqueLocusNames with the locus names and counts of each
			
			if (exists($UniqueLocusNames{$name})) {
			
				$UniqueLocusNames{$name}++;
			}
			
			else {			#It's a new locus name - push the location to NumbersWanted and the name to UniqueLoci.
				$UniqueLocusNames{$name} = 1;
				push (@NumbersWanted, $CurrentElement);
				push (@UniqueLoci, $name);
			}
			$CurrentElement++;
		}
		$Counter++;
		
	


		for my $key (keys(%UniqueLocusNames))  {	#subtract 1 from each value in the hash, to have the number of times the unique locus is repeated
	
			my $NewCount = $UniqueLocusNames{$key}-1;
	
			$UniqueLocusNames{$key} = $NewCount;
	
		}
		
		foreach my $LocusName (@UniqueLoci)  {	#Create the header line (names) in NoDupsOutHaplotypesForMonoTest.txt
			
			print NODUPSOUT "\t$LocusName";
		}
		
		my $NumInNumbersWanted = @NumbersWanted;
		my $NumInUniqueLoci = @UniqueLoci;
		
	}

	
	
	else {	 #We're on a line of SNP matrix that has genotypes (not the header line)
		chomp($_);
		$_ =~ s/"//g;
		my @TempArray = split (/\t/, "$_");
		
		print NODUPSOUT "\n$TempArray[0]";	#print the sample name
		
		foreach my $Number (@NumbersWanted)  {
			
			my $CurrentUniqueLocusName = $TotalLocusNames[$Number];
			
			if ($UniqueLocusNames{$CurrentUniqueLocusName} == 0)  {			#if the count associated with that number is zero, it's a single - print it
			
			   print NODUPSOUT "\t$TempArray[$Number+1]";
			}
			
			else {
				print NODUPSOUT "\t$TempArray[$Number+1]";
				my $TempNumberWanted = $UniqueLocusNames{$CurrentUniqueLocusName};
				
				foreach my $number (1..$TempNumberWanted)  {
					print NODUPSOUT "$TempArray[$Number+1+$number]";
				}
			}	
		}
	}
}


close NODUPSOUT;
close SNPMATRIX;


open NODUPS, "TempFiles/NoDupsOutHaplotypes.txt" or die$!;

if ($MaxLocation == 0)  {
	open NODUPSUPDATED, ">Output/Genotypes/Haplotypes_$MinPercentMult.All.txt" or die$!;
}

else {
	open NODUPSUPDATED, ">Output/Genotypes/Haplotypes_$MinPercentMult.$MaxLocation.txt" or die$!;
}	

while (<NODUPS>)  {

	$_ =~ s/(NA)+/NA/g;
	
print NODUPSUPDATED "$_";	
}	


close NODUPS;
close NODUPSUPDATED;




if ($MaxLocation == 0)  {
	
	open SNPMATRIX, "Output/Genotypes/SNPMatrix_$MinPercentMult.All.Temp.txt" or die$!;
	open OUT, ">Output/Genotypes/SNPMatrix_$MinPercentMult.All.txt" or die$!;
	
		while (<SNPMATRIX>)  {
			$_ =~ s/"//g;
			print OUT "$_";
		}	
}

else {
	
	open SNPMATRIX, "Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.Temp.txt" or die$!;
	open OUT, ">Output/Genotypes/SNPMatrix_$MinPercentMult.$MaxLocation.txt" or die$!;
	
		while (<SNPMATRIX>)  {
			$_ =~ s/"//g;
			print OUT "$_";
		}	

}

close SNPMATRIX;
close OUT;




