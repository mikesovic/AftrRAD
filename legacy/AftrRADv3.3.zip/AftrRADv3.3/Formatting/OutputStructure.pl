#! /usr/bin/perl
use warnings;
use strict;



print "Enter the name of the haplotype matrix file (in Results directory) you want to use. This file will be used to determine what loci are included in the Structure input. (include '.txt' extension)\n";
my $FileName = <STDIN>;
chomp($FileName);

#Replace any NA's in Haplotypes file with "N"

my $Counter1 = 0;

open HAPLOTYPEFILEWITHNA, "../Output/Genotypes/$FileName" or die$!;
open STRUCTUREFILENONA, ">OutputStructure_Infile_Temp.txt" or die$!;

	while (<HAPLOTYPEFILEWITHNA>)  {
		chomp($_);	

		if ($Counter1 == 0)  {
			$Counter1++;
			print STRUCTUREFILENONA "$_";
		}
		
		else {
			my @TempArray = split(/\t/, $_);
			my $Length = @TempArray;
			print STRUCTUREFILENONA "$TempArray[0]\t";
			
			foreach my $allele (@TempArray[1..$Length-1])  {
				$allele =~ s/NA/N/g;
				print STRUCTUREFILENONA "$allele\t";
			}
		}
		
		print STRUCTUREFILENONA "\n";
	}

close HAPLOTYPEFILEWITHNA;
close STRUCTUREFILENONA;


#Remove extra tabs at the end of each line. Final file is named "OutputStructure_Infile.txt".

open STRUCTURETEMP, "OutputStructure_Infile_Temp.txt" or die$!;
open STRUCTUREOUT, ">OutputStructure_Infile.txt" or die$!;

while (<STRUCTURETEMP>)  {
	$_ =~ s/\t$//;
	print STRUCTUREOUT "$_";
}

close STRUCTURETEMP;
close STRUCTUREOUT;




system "R --vanilla --slave < ../RScripts/OutputStructure.R";


open INFILE, "StructureInput_Temp.txt" or die$!;
open OUTFILE, ">StructureInput_Temp2.txt" or die$!;

my $LineCounter = 0;

while(<INFILE>) {
	if ($LineCounter == 0)  {
		$_ =~ s/"//g;
		$_ =~ s/^\s//;
		print OUTFILE "$_";
		$LineCounter++;
	}
	
	else {
		$_ =~ s/"//g;
		print OUTFILE "$_";
	}
}

close INFILE;
close OUTFILE;
	

system "rm OutputStructure_Infile_Temp.txt";
system "rm OutputStructure_Infile.txt";
system "rm StructureInput_Temp.txt";



my $SortCounter = 0;


	open INFILE, "StructureInput_Temp2.txt" or die$!;
	open OUTFILE, ">StructureInput.txt" or die$!;
	
	my @UnsortedArray = ();
	
	while (<INFILE>) {
		if ($SortCounter == 0) {
			print OUTFILE "$_";
			$SortCounter++;
		}
		
		else {
			chomp($_);
			my($first, $rest) = split(/\t/, $_, 2);
			push (@UnsortedArray, $first);
			push (@UnsortedArray, $rest);
		}
		
	}
	
	

	my %HashToSort = @UnsortedArray;

	my @SortedNames = sort { lc($a) cmp lc($b) } keys %HashToSort;

	close INFILE;
	
	
	foreach my $name (@SortedNames)  {
		
		open INFILE, "StructureInput_Temp2.txt" or die$!;
		
		while (<INFILE>)  {
			
			chomp($_);
			my @TempArray = split(/\t/, $_);
			
			if ($TempArray[0] eq $name)  {
				$_ =~ s/Individual//;
				print OUTFILE "$_\n";
			}
		}
		
		close INFILE;
	}	
	
	close OUTFILE;

system "rm StructureInput_Temp2.txt";	
	
