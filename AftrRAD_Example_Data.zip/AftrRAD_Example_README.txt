Example data and barcode files for AftrRAD.
Note that this dataset is intentionally very small (as RADseq datasets go), to make it easy to transfer, and quick to run. 


To test AftrRAD, move the example barcodes file into the 'Barcodes' folder in the AftrRAD directory and move the example data file into the 'Data' folder.

Rename these files to make the names match (including the extension - see User Guide).


Run AftrRAD with the following command (make sure all dependencies are installed first - see User Guide)…

perl AftrRAD.pl minDepth-3



If things run correctly, the following should eventually be printed to the terminal window.....


Performing heuristic search of all pairwise comparisons to identify potentially allelic pairs.
Rapidly searching unique sequence number 1000 of 3587 for potentially allelic read pairs.
Rapidly searching unique sequence number 2000 of 3587 for potentially allelic read pairs.
Rapidly searching unique sequence number 3000 of 3587 for potentially allelic read pairs.

Number of pairwise comparisons to align and evaluate is 3280
Aligning all potentially alleleic read pairs with ACANA.
Working on alignment 1000 of 3280.
Working on alignment 2000 of 3280.
Working on alignment 3000 of 3280.

Scoring each pairwise alignment.  Alignments exceeding 90 % similarity will be retained.
Parsing aligned sequences into candidate loci.
Globally aligning locus 100 of 367.
Globally aligning locus 200 of 367.
Globally aligning locus 300 of 367.
Finished writing the mafft output.
Identifying and removing paralogous loci.


Loci have been identified.  Aligned polymorphic loci are stored in the Output directory.  Read counts for the alleles at these loci can be found for each individual in the files stored in TempFiles/RawReadCountFiles.

Demultiplexing and other general information can be found for each dataset analyzed in the Output/RunInfo directory.

Next, run Genotype.pl, followed by FilterSNPs.pl to genotype all individuals and output SNPs for subsequent analyses.






If this is the output you get, things are running correctly.  Next, run Genotype.pl with the following command..

perl Genotype.pl MinReads-3

When it asks if you want to remove any samples, type 'n'.


Finally, run FilterSNPs.pl...

perl FilterSNPs.pl


Note that generally, I don't recommend setting MinReads as low as 3 (default is 10), but it helps with this example dataset because the dataset has been reduced to such a small size, and is for example purposes only.



Once FilterSNPs.pl is complete, you should have the following...


Output/PolymorphicLoci folder containing 367 aligned loci.
Output/Genotypes/Haplotypes_100.All.txt file containing 71 loci scored in all 12 samples.
Output/Genotypes/Monomorphics_100.txt file containing 262 reads that were monomorphic, and scored in all 12 samples.


If your data match these, AftrRAD is installed and running correctly.

